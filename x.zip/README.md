
# UP REPO DEBIAN
<pre><code>apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot</code></pre>
# UP REPO UBUNTU
<pre><code>apt update && apt upgrade -y && update-grub && sleep 2 && reboot</pre></code>

### INSTALL SCRIPT 
<pre><code>apt install -y && apt install lolcat -y && gem install lolcat && wget -q https://sky.myawan.web.id/install.sh && chmod +x install.sh && ./install.sh
</code></pre>

### PERINTAH UPDATE 
<pre><code>wget https://sky.myawan.web.id/desain-update.sh && chmod +x desain-update.sh && ./desain-update.sh</code></pre>

### TESTED ON OS 
- UBUNTU 20.04.05
- DEBIAN 10

### PORT INFO
```
- TROJAN WS 443
- TROJAN GRPC 443
- SHADOWSOCKS WS 443
- SHADOWSOCKS GRPC 443
- VLESS WS 443
- VLESS GRPC 443
- VLESS NONTLS 80
- VMESS WS 443
- VMESS GRPC 443
- VMESS NONTLS 80
- SSH WS / TLS 443
- SSH NON TLS 8880
- OVPN SSL/TCP 1194
- SLOWDNS 5300
```
### Author
```
```
LunaticTunnel :<a href="https://t.me/LunaticTunnel" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br>
```
```
``
```
